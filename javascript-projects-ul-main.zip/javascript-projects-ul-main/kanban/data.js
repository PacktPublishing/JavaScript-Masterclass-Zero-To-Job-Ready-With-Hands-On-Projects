const data = [
    {
      "columnId":0,
      "tasks":[
        {"taskId":97522,"content":"Record JavaScript Intro"},
        {"taskId":7243,"content":"Record Kanban Project"}
      ]
    },
    {
      "columnId":1,
      "tasks":[
        {"taskId":38833,"content":"System Design Notes"}
      ]
    },
    {
      "columnId":2,
      "tasks":[
        {"taskId":88198,"content":"React Projects"},
        {"taskId":23030,"content":"Edit OOPS Lectures"}
      ]
    }
];
  