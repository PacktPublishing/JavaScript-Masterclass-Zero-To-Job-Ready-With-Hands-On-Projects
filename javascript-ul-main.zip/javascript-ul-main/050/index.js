// const brandName = document.querySelector("#website-name");
// brandName.setAttribute("style", "color: blue;");


// const brandName = document.querySelector("#website-name");
// console.log(brandName.style);


// const brandName = document.querySelector("#website-name");
// brandName.style.margin = "50px";
// console.log(brandName.style.margin);


// const brandName = document.querySelector("#website-name");
// brandName.style.color = "blue";
// console.log(brandName.style.margin);


// const brandName = document.querySelector("#website-name");
// brandName.style.fontSize = "100px";
// console.log(brandName.style.fontSize);
