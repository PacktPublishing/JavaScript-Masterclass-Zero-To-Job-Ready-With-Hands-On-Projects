let selectorId = document.getElementById("website-name");
console.log(selectorId);

let selectorClass = document.getElementsByClassName("active");
console.log(selectorClass);

let selectorTag = document.getElementsByTagName("p");
console.log(selectorTag);