// Let example
let age = 25;
console.log(age);

age = 35;
console.log(age);

// Constant example
const score = 10;
console.log(score);

/* var year = 2025; 
console.log(year); */