let studentName = "Shubham";

const welcome = () => {
    console.log(`Welcome ${studentName}`);
};

welcome();