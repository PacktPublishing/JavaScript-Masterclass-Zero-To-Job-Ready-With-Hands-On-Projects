"use strict";

var studentName = "Shubham";

var welcome = function welcome() {
  console.log("Welcome ".concat(studentName));
};

welcome();
