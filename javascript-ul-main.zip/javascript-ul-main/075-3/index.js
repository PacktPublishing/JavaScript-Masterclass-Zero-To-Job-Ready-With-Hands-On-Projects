const numbers = [5, 3, 2, 7, 9, 1];
numbers.reverse();
console.log(numbers);


// const numbers = [5, 3, 2, 7, 9, 1];
// numbers.sort();
// numbers.reverse();
// console.log(numbers);



// const movies = [
//     {name: "Bug Finder", rating: 10},
//     {name: "Lost Coder", rating: 7},
//     {name: "Dev At Night", rating: 9},
//     {name: "Speed-Quality", rating: 8}
// ];
// movies.reverse();
// console.log(movies);