console.log("A");
setTimeout(() => {
    console.log("B");
}, 1000);
console.log("C");



// console.log("A");
// const welcome = function(){
//     console.log("B");
//     console.log("C");
// }
// setTimeout(, 1000);
// console.log("D");



// console.log("A");

// const random = function(){
//     const numOne = 5;
//     const numTwo = 15;
//     console.log(numOne + numTwo);
// }
// const welcome = function(){
//     console.log("B");
//     random();
//     console.log("C");
// }
// setTimeout(welcome, 1000);

// console.log("D");