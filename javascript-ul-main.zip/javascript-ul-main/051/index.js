// const activeClasses = document.querySelectorAll("li.active");
// const inActiveClasses = document.querySelectorAll("li.inactive");

// activeClasses.forEach(active => {
//     active.classList.remove("active");
//     active.classList.add("inactive");
// });
// inActiveClasses.forEach(active => {
//     active.classList.remove("inactive");
//     active.classList.add("active");
// });



// const activeClasses = document.querySelectorAll("li.active");
// activeClasses.forEach(active => {
//     active.classList.remove("active");
//     active.classList.add("inactive");
// });
// const newActiveClasses = document.querySelectorAll("li.inactive");
// newActiveClasses.forEach(active => {
//     active.classList.remove("inactive");
//     active.classList.add("active");
// });



// const brandName = document.querySelector("#website-name");
// brandName.classList.toggle("important");