import Kanban from "./kanban.js";

console.log(Kanban.getAllTasks());