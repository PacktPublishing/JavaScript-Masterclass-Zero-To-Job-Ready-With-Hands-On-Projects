let firstName = "Shubham";
let lastName = "Sarda";

// Concatination
console.log(firstName, lastName);

let fullName = firstName + lastName;
console.log(fullName);

let random = firstName + " " + lastName;
console.log(random);

// Accessing Characters
console.log(lastName[0]);
console.log(lastName[1]);
console.log(lastName[2]);
console.log(lastName[3]);
console.log(lastName[4]);

// Properties
console.log(firstName.length);
console.log(lastName.length);

// Methods
console.log(firstName.toUpperCase());
console.log(lastName.toLowerCase());

