const numbers = [5, 20, 75, 80, 15, 30];

const findNumbers = numbers.find((num) => {
    return num > 70;
});
console.log(findNumbers);



// const numbers = [5, 20, 75, 80, 15, 30];
// const findNumbers = numbers.find(num => num === 50);
// console.log(findNumbers);