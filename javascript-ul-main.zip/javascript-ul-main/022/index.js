let score = 9;
if(score > 7){
    console.log("Good job!");
}

// const students = ["shubham", "alex", "deepak", "john"];
// if(students.length > 0){
//     console.log("We have a class today!");
// }

console.log("Out of condition!");