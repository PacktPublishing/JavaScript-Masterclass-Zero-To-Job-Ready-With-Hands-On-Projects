let user = {
    name: "Shubham Sarda",
    email: "shubham@gmail.com",
    age: 25,
    isLoggedIn: false
};


console.log(user);
console.log(user.name);


// console.log(user.isLoggedIn);
// user.isLoggedIn = true;
// console.log(user.isLoggedIn);


// let key = "email";
// console.log(user.key)
// console.log(user["email"]);


// console.log(user);
// console.log(typeof user);