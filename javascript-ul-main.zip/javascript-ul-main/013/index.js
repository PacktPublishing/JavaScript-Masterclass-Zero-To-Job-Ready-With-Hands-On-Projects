let products = ["bread", "butter", "salt", "jam"];
// let update = ["pizza", "water"];

let productsMethod = products.join(", ");
console.log(productsMethod);
console.log(products);

// let productsMethod = products.indexOf("bread");
// console.log(productsMethod);
// console.log(products);

// let productsMethod = products.concat(update);
// console.log(productsMethod);
// console.log(products);

// let productsMethod = products.concat(["water", "bottle"]);
// console.log(productsMethod);
// console.log(products);

// let productsMethod = products.push("water");
// console.log(productsMethod);
// console.log(products);

// let productsMethod = products.pop("jam");
// console.log(productsMethod);
// console.log(products);