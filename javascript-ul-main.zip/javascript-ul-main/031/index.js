// let name = "Shubham";

// function welcome(name){
//     console.log(`Welcome ${name}`);
// }
// welcome("Shubham");


// function addition(numOne, numTwo){
//     let result = numOne + numTwo;
//     console.log(result);
// }
// addition(5, 10);


// function fullName(firstName, lastName){
//     console.log(`WELCOME ${firstName} ${lastName}`);
// }
// fullName("Shubham", "Sarda");


// function fullName(firstName="ABC", lastName="XYZ"){
//     console.log(`WELCOME ${firstName} ${lastName}`);
// }
// fullName("Shubham", "Sarda");
// fullName();


// function addition(numOne = 0, numTwo = 0){
//     let result = numOne + numTwo;
//     console.log(result);
// }
// addition(5, 10);
// addition(5);