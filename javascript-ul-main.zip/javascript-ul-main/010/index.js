let firstName = "Shubham";
let lastName = "Sarda";
let random = "Learning JavaScript";

// console.log(firstName.toUpperCase());
// console.log(lastName.toLowerCase());

// console.log(firstName.indexOf("h"));
// console.log(firstName.lastIndexOf("h"));

// console.log(firstName.replace("h", "-"));
// console.log(firstName.replaceAll("h", "-"));

// console.log(random.substring(0, 8));
// console.log(random.substring(9, 19));

// console.log(random.slice(0, 8));
// console.log(random.slice(9, 19));

console.log(firstName.startsWith("S"));
console.log(firstName.endsWith("m"));
console.log(random.includes("script"));

console.log(firstName);