// let random = 20;
// console.log(random);


// function intro(){
//     console.log("Welcome to the course!");
// }
// intro();


// let intro = function(){
//     console.log("Welcome to the course!");
// };
// intro();



// welcome();
// function welcome(){
//     console.log("Hoisting Example!");
// }