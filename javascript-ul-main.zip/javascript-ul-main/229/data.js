const transactions = [
    {id: 123, source: "Freelancing", amount: 499, time: "4:40:38 AM 5/19/2022"},
    {id: 124, source: "Studio", amount: -49, time: "5:40:38 AM 5/19/2022"},
    {id: 125, source: "Cash", amount: 500, time: "7:40:38 AM 5/19/2022"},
    {id: 126, source: "Recording", amount: 200, time: "9:40:38 AM 5/19/2022"},
];