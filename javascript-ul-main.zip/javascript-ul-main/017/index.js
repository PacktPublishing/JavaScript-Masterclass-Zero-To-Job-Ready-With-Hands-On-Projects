// let random = "25";
// console.log(typeof random);
// let age = Number(random);
// console.log(typeof age);

// let year = 1996;
// console.log(typeof year)
// let yearString = String(year);
// console.log(typeof yearString);

// let random = "xyz";
// let value = Number(random);
// console.log(value);
// console.log(typeof value);

// let result = Boolean(80);
// console.log(result);
// console.log(typeof result);
// falsy values: 0 , null , undefined , false , NaN , and "" 