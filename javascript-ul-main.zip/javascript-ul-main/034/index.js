let welcome = () => "WELCOME";
console.log(welcome());


let myName = "Shubham";
console.log(myName.toLowerCase());


let students = ["alex", "deepak"];
console.log(students.push("john"));