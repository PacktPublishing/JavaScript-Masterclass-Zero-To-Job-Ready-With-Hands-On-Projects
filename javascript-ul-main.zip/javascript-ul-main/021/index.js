// let count = 5;
// while(count < 5){
//     console.log("Hello!");
//     count++;
// }

let count = 15;
do{
    console.log(count);
    count++
}
while(count < 5);

console.log("Out of loop!");