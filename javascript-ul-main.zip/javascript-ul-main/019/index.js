let students = ["shubham", "alex", "mark", "deepak"];

// for(let count = 0; count < 5; count++){
//     console.log("Hello!");
// }

// for(let i = 0; i < 4; i++){
//     console.log(students[i]);
// }

for(let i = 0; i < students.length; i++){
    console.log(students[i]);
}

console.log("Out of loop!");