let age = 25;

// console.log(age == 25);
// console.log(age == "25");
// console.log(age === "25");

// console.log(typeof age);
// console.log(typeof "25");

// console.log(age == 25);
// console.log(age != "25");
// console.log(age !== "25");

// console.log(typeof age);
// console.log(typeof "25");