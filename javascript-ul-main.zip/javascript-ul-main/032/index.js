function addition(numOne, numTwo){
    let result = numOne + numTwo;
    return result;
}
const value = addition(5, 10);
console.log(value);


// function fullName(firstName, lastName){
//     let result = firstName + " " + lastName;
//     return result;
// }
// const value = fullName("Shubham", "Sarda");
// console.log(value);


// function fullName(firstName, lastName){
//     let result = firstName + " " + lastName;
//     console.log(result);
// }
// const value = fullName("Shubham", "Sarda");
// console.log(value);