console.log(document);

console.log(document.location);
console.log(document.domain);
console.log(document.URL);
console.log(document.title);