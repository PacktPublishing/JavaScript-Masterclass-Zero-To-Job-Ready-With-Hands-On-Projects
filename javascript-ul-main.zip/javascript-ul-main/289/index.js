import Kanban from "./kanban.js";

// console.log(Kanban.getAllTasks());
// console.log(Kanban.getTasks(1));


// console.log(Kanban.getTasks(1));
// console.log(Kanban.insertTask(1, "Edit Kanban Project Lectures"));
// console.log(Kanban.getTasks(1));


// console.log(Kanban.getAllTasks());
// Kanban.deleteTask(11822);
// console.log(Kanban.getAllTasks());


// console.log(Kanban.getAllTasks());
// Kanban.updateTask(97522, {
//     columnId: 2,
//     content: "Record JavaScript Preview"
// });
// console.log(Kanban.getAllTasks());

