let score = 7;
console.log(score);

let update = null;
console.log(update);
console.log(update, update + 20, `My score is ${update}`);

let year;
console.log(year);
console.log(year, year + 20, `My score is ${year}`);