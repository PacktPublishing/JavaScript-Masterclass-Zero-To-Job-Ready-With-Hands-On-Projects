const value = {
    name: "shubham",
    age: 26
};