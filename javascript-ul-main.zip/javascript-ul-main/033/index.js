let welcome = function(){
    console.log("WELCOME");
};
welcome();


let intro = () => {
    console.log("WELCOME ARROW V1");
};
intro();


let welcomeArrow = (name) => {
    console.log("WELCOME ARROW V2", name);
};
welcomeArrow("SHUBHAM");


// let intro = () => `WELCOME`;
// console.log(intro());

// let welcome = name => `WELCOME ${name}`;
// console.log(welcome("SHUBHAM"));

// let add = (numOne, numTwo) => numOne + numTwo;
// console.log(add(2, 5));