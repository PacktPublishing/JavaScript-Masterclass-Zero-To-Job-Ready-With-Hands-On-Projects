let radius = 15;
const pi = 3.14;
let random = "XYZ";

// Operations: + - * / **
// let area = pi*radius**2;
// console.log(area);

// BODMAS: () ** / * + -
// let result = 15*(20-18)**3;
// console.log(result);

// Shorthand Version
// radius++
// console.log(radius);

// radius--
// console.log(radius);

// radius += 5;
// console.log(radius);

// radius -= 10;
// console.log(radius);

// Concatenation
// let result = "My Radius is " + radius + " and Value of PI is " + pi;
// console.log(result);