let products = ["bread", "butter", "jam", "bottle"];
products.forEach(product => console.log(product));


// let students = ["shubham", "alex", "deepak", "john"];
// students.forEach((student, index) => {
//     console.log(student, index);
// });


// let userCallback = (user, index) => {
//     console.log(user, index);
// }

// let users = ["shubham", "alex", "deepak", "john"];
// users.forEach(userCallback);