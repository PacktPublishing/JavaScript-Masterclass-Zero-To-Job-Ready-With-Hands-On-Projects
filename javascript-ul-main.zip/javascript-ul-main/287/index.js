import Kanban from "./kanban.js";

// console.log(Kanban.getAllTasks());
// console.log(Kanban.getTasks(0));

// console.log(Kanban.insertTask(1, "Edit Kanban Project Lectures"));