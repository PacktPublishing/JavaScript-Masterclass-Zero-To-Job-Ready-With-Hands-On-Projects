// const link = document.querySelector("a");
// console.log(link.getAttribute("href"));
// link.setAttribute("href", "www.example.com");
// console.log(link.getAttribute("href"));


// link.setAttribute("target", "_blank");


// const activeClasses = document.querySelectorAll(".active");
// activeClasses.forEach(active => {
//     console.log(active.getAttribute("class"));
//     active.setAttribute("class", "highlight");
//     console.log(active.getAttribute("class"));
// });


// const brandName = document.querySelector("#website-name");
// brandName.setAttribute("style", "color: blue;")