export const username = "shubham";
export const age = 26;

export function connect(){
    return `${username} is connected!`;
}

export function disconnect(){
    return `${username} is disconnected!`;
}