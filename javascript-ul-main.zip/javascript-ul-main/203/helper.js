export function convert(value){
    return value * 9.8;
}