const productAdd = document.querySelector("button");
productAdd.addEventListener("click", () => {
    console.log("Button Clicked!");
    productAdd.setAttribute("style","display: none");
});