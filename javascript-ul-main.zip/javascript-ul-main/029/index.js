function addition(numOne, numTwo){
    return numOne + numTwo;
}

console.log(addition(2, 5));
console.log(addition(5, 10));
console.log(addition(100, 500));
console.log(addition(2, 0.5));
console.log(addition(705, 0.01));
console.log(addition(173, 5));