let value = [true, false, "true", "false"];
console.log(value);

// let email = "shubham@gmail.com";
// console.log(email.includes("shubham"));

// let students = ["alex", "john", "deepak", "tanvi"];
// console.log(students.includes("mark"));

// let age = 20;
// console.log(age == 25);
// console.log(age == 35);

// console.log(age != 53);

// console.log(age > 35);
// console.log(age < 30);

// console.log(age >= 25);
// console.log(age <= 20);

// console.log("abc" > "xyz");
// console.log("abc" > "ABC");
// https://i.pinimg.com/originals/68/54/5d/68545d41a27ee34f61ec88c442459f4c.png
