console.log("A");

setTimeout(() => {
    console.log("B");
}, 0);

console.log("C");



// console.log("A");

// const logInterval = setInterval(() => {
//     console.log("Interval");
// }, 1000);
// clearInterval(logInterval);

// console.log("C");