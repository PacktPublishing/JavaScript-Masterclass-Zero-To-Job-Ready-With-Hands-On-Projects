// const topNav = document.querySelector(".top-nav");
// const topNavChildren = Array.from(topNav.children);
// topNavChildren.forEach(child => {
//     child.classList.add("random");
//     console.log(child);
// });

// const brandName = document.querySelector("#website-name");
// console.log(brandName.parentElement.children);

const blogHeading = document.querySelector(".sub-heading");
console.log(blogHeading.previousElementSibling);
console.log(blogHeading.nextElementSibling);