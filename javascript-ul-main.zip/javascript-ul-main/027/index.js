let rating = 5;

switch(rating){

    case 5:
        console.log("MUST WATCH");
        break;
    
    case 4:
        console.log("GOOD OPTION");
        break;
    
    case 3:
        console.log("MAYBE");
        break;

    case 2:
        console.log("SKIP");
        break;
    
    case 1:
        console.log("IGNORE");
        break;
    
    default:
        console.log("INVALID");
}

// let rating = 5;
// if(rating == 5){
//     console.log("MUST WATCH");
// } else if(rating == 4){
//     console.log("GOOD OPTION");
// } else if(rating == 3){
//     console.log("MAYBE");
// } else if(rating == 2){
//     console.log("SKIP");
// } else if(rating == 1){
//     console.log("IGNORE");
// } else {
//     console.log("INVALID");
// }
