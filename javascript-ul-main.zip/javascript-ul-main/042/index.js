const num = 15.3;

console.log(Math);
console.log(Math.PI);
console.log(Math.E);

console.log(Math.round(num));
console.log(Math.ceil(num));
console.log(Math.floor(num));
console.log(Math.pow(2, 5));
console.log(Math.sign(num));

let random = Math.random() * 100
console.log(Math.round(random));