import Kanban from "./kanban.js";

// console.log(Kanban.getAllTasks());
console.log(Kanban.getTasks(4));