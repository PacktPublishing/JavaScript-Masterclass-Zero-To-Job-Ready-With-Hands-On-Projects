// const result = 10 > 2;
// if(result){
//     console.log("true value");
// } else {
//     console.log("false value");
// }


const user = true;
user ? console.log("true value") : console.log("false value");


// const username = "shubham";
// username.length >= 5 ? (console.log("true")) : (console.log("false"));


// const username = "abc";
// const result = username.length >= 5 ? username.length : 0;
// console.log(result);