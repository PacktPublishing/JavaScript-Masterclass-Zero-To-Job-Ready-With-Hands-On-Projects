const numbers = [5, 3, 2, 7, 9, 1];
numbers.sort();
console.log(numbers);



// const names = ["shubham", "john", "deepak", "alex"];
// names.sort()
// console.log(names);



// const numbers = [5, 10, 7, 2, 9, 30];
// numbers.sort((a, b) => {
//     return a-b;
// });
// console.log(numbers);



// const movies = [
//     {name: "Bug Finder", rating: 10},
//     {name: "Lost Coder", rating: 7},
//     {name: "Dev At Night", rating: 9},
//     {name: "Speed-Quality", rating: 8}
// ];
// movies.sort((a, b) => a.rating - b.rating);
// console.log(movies);