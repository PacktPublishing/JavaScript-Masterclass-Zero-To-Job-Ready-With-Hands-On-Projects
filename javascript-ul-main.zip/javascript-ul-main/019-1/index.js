const students = ["shubham", "alex", "mark", "deepak"];

for(let student of students){
    console.log(student);
}

// for(let index in students){
//     console.log(students[index]);
// }


// const student = {
//     username: "shubham",
//     age: 26
// };
// for(let key in student){
//     console.log(student[key]);
// }


// const username = "shubham";
// for(let character of username){
//     console.log(character);
// }


console.log("Out of loop!");