export const add = (numOne, numTwo) => {
    return numOne + numTwo
}

export const sub = (numOne, numTwo) => {
    return numOne - numTwo
}

export const multiply = (numOne, numTwo) => {
    return numOne * numTwo
}

export const divide = (numOne, numTwo) => {
    return numOne / numTwo
}