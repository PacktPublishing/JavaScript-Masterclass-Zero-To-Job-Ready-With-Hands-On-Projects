const words = ["Adventurous", "Adventurous", "Adventurous", "Brave"];
export const names = ["shubham", "alex", "deepak", "john"];