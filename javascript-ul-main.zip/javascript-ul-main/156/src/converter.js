export const convertKmToM = (value) => {
    return value * 1000;
}

export const convertMToKm = (value) => {
    return value / 1000;
}

export const convertKgToG = (value) => {
    return value * 1000;
}

export const convertGToKg = (value) => {
    return value / 1000;
}