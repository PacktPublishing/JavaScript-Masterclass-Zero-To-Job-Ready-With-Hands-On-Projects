import Kanban from "./kanban.js";

// console.log(Kanban.getAllTasks());
// console.log(Kanban.getTasks(1));

// console.log(Kanban.insertTask(1, "Edit Kanban Project Lectures"));
// Kanban.deleteTask(11822);

console.log(Kanban.getTasks(1));