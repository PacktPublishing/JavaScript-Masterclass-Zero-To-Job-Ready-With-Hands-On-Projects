let score = 5;
if(score > 7){
    console.log("Good job!");
} else {
    console.log("All the best for next one!");
}


// const loggedIn = true;
// if(loggedIn){
//     console.log("Welcome user!");
// } else {
//     console.log("Please login first!");
// }


// let signal = "red";
// if(signal == "red"){
//     console.log("Please STOP!");
// } else if(signal == "yellow"){
//     console.log("Get READY!");
// } else if(signal == "green"){
//     console.log("Goooooooo!");
// } else {
//     console.log("Please check the signal input!")
// }


// let score = 9;
// if(score == 10){
//     console.log("Great work, perfect 10!");
// } else if(score == 9){
//     console.log("Sooo Close!");
// } else if(score == 8){
//     console.log("Great work, keep going!");
// } else if(score == 7){
//     console.log("Just a little brush up!");
// } else if(score == 6){
//     console.log("You need practice!");
// } else if(score == 5){
//     console.log("Hmmm, you need to work on it!");
// } else if(score == 4){
//     console.log("You need focus!");
// } else if(score == 3){
//     console.log("You need focus!!");
// } else if(score == 2){
//     console.log("You need focus!");
// } else if(score == 1){
//     console.log("You need focus!");
// } else {
//     console.log("Invalid score!");
// }


console.log("Out of condition!");