let students = ["shubham", "alex", "mark", "deepak"];

// for(let count = 0; count < 5; count++){
//     console.log("Hello!");
// }

let count = 0;
while(count < 5){
    console.log("Hello!");
    count++;
}

// while(true){
//     console.log("Hello!");
// }

// let i = 0;
// while(i < students.length){
//     console.log(students[i]);
//     i++;
// }

console.log("Out of loop!");