// console.log(!true);
// console.log(!false);


// let loggedIn = true;
// if(!loggedIn){
//     console.log("Hello!");
// } else {
//     console.log("else case!");
// }


// let loggedIn = "";
// if(!loggedIn){
//     console.log("Hello!");
// } else {
//     console.log("else case!");
// }