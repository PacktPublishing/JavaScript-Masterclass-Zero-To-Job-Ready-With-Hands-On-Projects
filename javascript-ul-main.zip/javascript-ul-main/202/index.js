const username = 52;
const age = 27;

// if (typeof username !== "string"){
//     throw Error("Not an String");
// }

if (age > 25){
    throw Error("Invalid Age!");
}