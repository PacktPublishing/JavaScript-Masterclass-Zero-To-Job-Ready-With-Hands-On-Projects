// let description = document.querySelector('p');
// console.log(description);


// let description = document.querySelector('.active');
// console.log(description);


// let description = document.querySelector('#website-name');
// console.log(description);


// let description = document.querySelectorAll('p');
// console.log(description);
// console.log(description[0]);
// console.log(description[1]);
// console.log(description[2]);


// let description = document.querySelectorAll('ul.footer-nav');
// console.log(description);


// let description = document.querySelectorAll('div p');
// description.forEach(paragraph => {
//     console.log(paragraph);
// });