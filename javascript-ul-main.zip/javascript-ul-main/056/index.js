// const products = document.querySelector("ul");
// const copyAlert = (event) => {
//     if(event.target.tagName === "LI"){
//         alert(event.target.textContent);
//     }
// }
// products.addEventListener('copy', copyAlert);


// const webPage = document.querySelector("body");
// webPage.addEventListener("mousemove", (event) => {
//     console.log(event.clientX, event.clientY);
// });


// const webPage = document.querySelector("body");
// webPage.addEventListener("wheel", (event) => {
//     console.log(event.pageX, event.pageY);
// });