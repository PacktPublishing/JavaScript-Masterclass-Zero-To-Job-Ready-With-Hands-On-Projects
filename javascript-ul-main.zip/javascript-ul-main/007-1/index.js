// Let example
let age = 20;
console.log(age);

let myAge = 25;
console.log(myAge);

myAge = 35;
console.log(myAge);

// Constant example
const score = 10;
console.log(score);

/* var year = 2025; 
console.log(year); */